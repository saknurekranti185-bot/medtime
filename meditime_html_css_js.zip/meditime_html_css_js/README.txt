MediTime — Medicine Reminder Website

Files:
- index.html: page structure
- style.css: responsive mobile design
- script.js: reminder logic, local storage, notification permission

Run locally:
1. Keep all three files in the same folder.
2. Open index.html in a modern browser.
3. Add a medicine name, dosage, and reminder time.

Notifications:
- Browser notifications usually require HTTPS or localhost.
- Click the Notifications button and allow permission.
- Time checks run while the page's JavaScript is active. Mobile browsers may suspend background tabs, so reminders are not guaranteed if the page is closed or suspended.

Free hosting with GitHub Pages:
1. Create a GitHub repository.
2. Upload index.html, style.css, and script.js to the repository root.
3. Open Settings > Pages.
4. Choose deployment from the main branch and root folder.
5. Save and wait for the published URL.

Data is stored in localStorage in this browser/device. There is no login, cloud sync, or database. This is a college project, not a medical device or medical advice.

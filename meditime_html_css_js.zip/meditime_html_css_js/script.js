const STORAGE_KEY = "meditime-reminders-v1";
const TAKEN_KEY = "meditime-taken-v1";
let reminders = loadData(STORAGE_KEY, []);
let taken = loadData(TAKEN_KEY, {});
let toastTimer;
let lastCheckedMinute = "";

// ---- Ringtone ----
const ringtone = document.getElementById("medRingtone");
let ringingId = null;

// Browsers block sound until the user clicks once on the page
document.addEventListener("click", () => {
  ringtone.play().then(() => { ringtone.pause(); ringtone.currentTime = 0; }).catch(() => {});
}, { once: true });

function startRing(id) {
  ringingId = id;
  ringtone.currentTime = 0;
  ringtone.play().catch(() => {});
}
function stopRing(id) {
  if (id && ringingId !== id) return;
  ringtone.pause();
  ringtone.currentTime = 0;
  ringingId = null;
}
// ------------------

function loadData(key, fallback) {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
  catch { return fallback; }
}
function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(reminders));
  localStorage.setItem(TAKEN_KEY, JSON.stringify(taken));
}
function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message; toast.style.display = "block";
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.style.display = "none", 2600);
}
function formatTime(value) {
  const [h,m] = value.split(":").map(Number);
  const d = new Date(); d.setHours(h,m,0,0);
  return d.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"});
}
function render() {
  const today = todayKey();
  reminders.sort((a,b) => a.time.localeCompare(b.time));
  document.getElementById("todayLabel").textContent = new Date().toLocaleDateString([], {weekday:"long",month:"short",day:"numeric"});
  document.getElementById("totalStat").textContent = reminders.length;
  document.getElementById("dueStat").textContent = reminders.length;
  document.getElementById("takenStat").textContent = reminders.filter(r => taken[`${today}_${r.id}`]).length;
  document.getElementById("reminderCount").textContent = `${reminders.length} reminder${reminders.length===1?"":"s"}`;
  const list = document.getElementById("reminderList");
  if (!reminders.length) {
    list.innerHTML = '<div class="card empty"><div class="empty-icon">💊</div><h3>No reminders yet</h3><p>Add your first medicine above to build your daily plan.</p></div>';
    return;
  }
  list.innerHTML = reminders.map(r => {
    const isTaken = Boolean(taken[`${today}_${r.id}`]);
    return `<article class="reminder-card"><div class="reminder-top">
      <div class="pill-icon">💊</div><div class="reminder-main">
      <div class="med-name">${escapeHTML(r.name)}</div>
      <div class="med-detail">${escapeHTML(r.dose || "Dosage not specified")}</div>
      ${r.notes ? `<div class="med-detail">📝 ${escapeHTML(r.notes)}</div>` : ""}
      <div class="status">${isTaken ? "✓ Marked as taken today" : "Daily reminder · Mark after taking"}</div>
      </div><div class="time-pill">${escapeHTML(formatTime(r.time))}</div></div>
      <div class="actions"><button class="secondary-btn ${isTaken?"is-taken":""}" data-action="taken" data-id="${r.id}">${isTaken?"✓ Taken today":"Mark as taken"}</button>
      <button class="secondary-btn delete" data-action="delete" data-id="${r.id}">Delete</button></div></article>`;
  }).join("");
}
document.getElementById("medicineForm").addEventListener("submit", event => {
  event.preventDefault();
  const name = document.getElementById("medName").value.trim();
  const time = document.getElementById("medTime").value;
  if (!name || !time) { showToast("Enter a medicine name and reminder time."); return; }
  reminders.push({id:`${Date.now()}-${Math.random().toString(36).slice(2,7)}`,name,dose:document.getElementById("dose").value.trim(),time,notes:document.getElementById("notes").value.trim()});
  saveData(); render(); event.target.reset(); document.getElementById("medTime").value = "09:00";
  showToast("Medicine reminder added.");
});
document.getElementById("reminderList").addEventListener("click", event => {
  const button = event.target.closest("button[data-action]"); if (!button) return;
  const {id,action} = button.dataset;
  if (action === "taken") {
    const key = `${todayKey()}_${id}`;
    if (taken[key]) { delete taken[key]; showToast("Taken status removed."); }
    else { taken[key] = true; stopRing(id); showToast("Dose marked as taken."); }
    saveData(); render();
  }
  if (action === "delete") {
    const medicine = reminders.find(r => r.id === id);
    if (medicine && confirm(`Delete the reminder for ${medicine.name}?`)) {
      stopRing(id);
      reminders = reminders.filter(r => r.id !== id); saveData(); render(); showToast("Reminder deleted.");
    }
  }
});
document.getElementById("notifyBtn").addEventListener("click", async () => {
  if (!("Notification" in window)) { showToast("Notifications are not supported in this browser."); return; }
  if (!window.isSecureContext && location.hostname !== "localhost") { showToast("Use HTTPS hosting to request notifications."); return; }
  try {
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      new Notification("MediTime", {body:"Test notification: browser notifications are enabled."});
      showToast("Notifications enabled where supported.");
    } else showToast("Notification permission was not granted.");
  } catch { showToast("Could not enable notifications."); }
});
// Reminder checks run while this page is active; mobile browsers may suspend background tabs.
function checkReminders() {
  const now = new Date();
  const currentTime = `${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;
  const minuteKey = `${todayKey()}_${currentTime}`;
  if (minuteKey === lastCheckedMinute) return;
  lastCheckedMinute = minuteKey;
  reminders.forEach(r => {
    const key = `${todayKey()}_${r.id}`;
    if (r.time !== currentTime || taken[key]) return;
    startRing(r.id); // <-- ringtone starts here
    showToast(`Reminder: ${r.name}${r.dose ? " · " + r.dose : ""}`);
    if ("Notification" in window && Notification.permission === "granted") {
      try { new Notification(`Medicine reminder: ${r.name}`, {body:r.dose || r.notes || "Please check your medicine plan."}); } catch {}
    }
  });
}
render(); checkReminders(); setInterval(checkReminders, 15000);